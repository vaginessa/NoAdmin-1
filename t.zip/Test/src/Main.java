
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Main extends Application
{
	@Override
	public void start(Stage stage)
	{

		// creating a Group as our root node
		Group root = new Group();

		// configuring a Canvas to draw on
		Canvas canvas = new Canvas();
		canvas.setWidth(600);
		canvas.setHeight(400);

		// drawing on the Canvas
		GraphicsContext gc = canvas.getGraphicsContext2D();
		draw(gc);

		canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>()
		{

			@Override
			public void handle(MouseEvent event)
			{
				System.out.println("Mouse clicked");
			}

		});

		// adding the Canvas to the scene graph
		root.getChildren().add(canvas);

		// adding the root to the scene
		Scene scene = new Scene(root);

		// adding the scene to the stage
		// and showing the stage/window
		stage.setScene(scene);
		stage.setTitle("Circles and Squares");
		stage.show();
	}

	private void reset(Canvas canvas, Color color)
	{
		GraphicsContext gc = canvas.getGraphicsContext2D();
		gc.setFill(color);
		gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
	}

	/**
	 * Drawing the shapes
	 */
	private void draw(GraphicsContext gc)
	{

		gc.setFill(Color.GREEN);
		gc.fillOval(25, 25, 50, 50);
		gc.setFill(Color.BLACK);
		gc.setTextAlign(TextAlignment.CENTER);
		gc.setTextBaseline(VPos.CENTER);
		gc.fillText("HI", 50, 50);
		gc.setFill(Color.RED);
		gc.fillOval(100, 25, 50, 50);
		gc.fillOval(175, 25, 50, 50);
		gc.fillOval(250, 25, 50, 50);
		gc.fillOval(325, 25, 50, 50);
		gc.fillOval(400, 25, 50, 50);
	}

	public static void main(String[] args)
	{
		launch(args);
	}
}