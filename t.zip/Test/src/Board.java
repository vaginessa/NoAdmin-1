import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.event.EventHandler;
import javafx.geometry.VPos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Board extends Application
{

	Circle circle_1, circle_2, circle_3;
	@Override
	public void start(Stage stage) throws Exception
	{
		circle_1 = new Circle(50.0f, Color.RED);
		circle_1.setCursor(Cursor.HAND);
		circle_1.setCenterX(75);
		circle_1.setCenterY(75);
        
		Group root = new Group();
		root.getChildren().addAll(circle_1);
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Circles and Squares");
		stage.show();

	}

	private Canvas addGrapics(double posX)
	{
		Canvas circle = new Canvas();
		circle.setWidth(600);
		circle.setHeight(400);
		
		GraphicsContext gc = circle.getGraphicsContext2D();
		gc.setFill(Color.GREEN);
		gc.fillOval(posX, 25, 50, 50);
		gc.setFill(Color.BLACK);
		gc.setTextAlign(TextAlignment.CENTER);
		gc.setTextBaseline(VPos.CENTER);
		gc.fillText("HI", posX+25, 50);
		return circle;
	}
	private void reset(Canvas canvas, Color color) {
	    GraphicsContext gc = canvas.getGraphicsContext2D();
	    gc.setFill(color);
	}
	public static void main(String[] args)
	{
		launch(args);
	}

}
