package awari;
public class studentAI extends Player {
    private int maxDepth;


    public void setMaxDepth(int maxDepth) {
        this.maxDepth = maxDepth;
    }

    public void move(BoardState state) {
        move = -1;
    }

    public int alphabetaSearch(BoardState state, int maxDepth) {
    	return -1;
    }

    public int maxValue(BoardState state, int maxDepth, int currentDepth, int alpha, int beta) {
    	return -1;
    }

    public int minValue(BoardState state, int maxDepth, int currentDepth, int alpha, int beta) {
    	return -1;
    }

    public int sbe(BoardState state){
    	return -1;
    }


}